import { ToKHRPipe } from './to-khr-pipe';

describe('ToKHRPipe', () => {
  it('create an instance', () => {
    const pipe = new ToKHRPipe();
    expect(pipe).toBeTruthy();
  });
});
