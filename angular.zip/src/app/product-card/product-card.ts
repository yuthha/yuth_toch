import {Component, Input} from '@angular/core';
import {CurrencyPipe} from '@angular/common';
import {ToKHRPipe} from '../custom-pipe/to-khr-pipe';

@Component({
  selector: 'app-product-card',
  imports: [
    CurrencyPipe,
    ToKHRPipe
  ],
  templateUrl: './product-card.html',
  styleUrl: './product-card.css'
})
export class ProductCard {
  @Input() product: any;
}
